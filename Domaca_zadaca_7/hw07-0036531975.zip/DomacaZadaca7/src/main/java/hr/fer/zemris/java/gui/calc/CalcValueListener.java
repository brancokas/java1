package hr.fer.zemris.java.gui.calc;

public interface CalcValueListener {
    /**
     * Metoda koja se poziva kao rezultat promjene
     * vrijednosti zapisane u kalkulator.
     *
     * @param model model kalkulatora u kojemu je došlo do promjene; ne može biti <code>null</code>
     */
    void valueChanged(CalcModel model);
}
