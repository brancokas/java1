package hr.fer.zemris.java.gui.layouts;

import java.awt.*;

public interface Size {
    public Dimension getSize(Component component);
}
