package hr.fer.oprpp1.jmbag0036531975;

public enum TokenType {
    FIELD, OPERATOR, LITERAL, AND;
}
