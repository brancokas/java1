package hr.fer.oprpp1.jmbag0036531975;

public interface IFieldValueGetter {
    public String get(StudentRecord record);
}
