package hr.fer.oprpp1.jmbag0036531975;

public interface IComparisonOperator {
    public boolean satisfied(String value1, String value2);
}
