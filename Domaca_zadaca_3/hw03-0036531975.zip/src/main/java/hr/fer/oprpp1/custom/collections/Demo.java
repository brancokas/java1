package hr.fer.oprpp1.custom.collections;

public class Demo {
    public static void main(String[] args) {

    }
}
