package hr.fer.oprpp1.custom.scripting.lexer;

public enum TokenType {
	EOF, TAG_START, TAG_END, DOUBLE, INTEGER, FUNCTION, OPERATOR, STRING, VARIABLE, FOR, EQUAL, TEXT, END; 
}
